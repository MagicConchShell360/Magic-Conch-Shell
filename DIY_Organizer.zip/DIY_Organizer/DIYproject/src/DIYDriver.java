/*
 * Magic Conch Shell
 * Kevin Santos, Joseph Joo, Sally Ho
 */

/**
 * This is a driver class to run DIYMain.
 * 
 * @author Kevin Santos
 */
public class DIYDriver {

	/**
	 * @author Kevin Santos
	 */
	public static void main(String[] args) {
		DIYMain control = new DIYMain();
		control.setVisible(true);
	}

}
